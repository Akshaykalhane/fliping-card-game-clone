import React from "react";
import FlippingCardMemoryGame from "./module/pages/FlippingCardMemoryGame";

export default function App() {
  return (
    <>
      <FlippingCardMemoryGame />
    </>
  );
}
