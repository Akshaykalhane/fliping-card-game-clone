import {
  backCard01,
  backCard02,
  backCard03,
  backCard04,
  backCard05,
  backCard06,
  backCard07,
  backCard08,
  backCard09,
  backCard10,
} from "../assets/cards/backCards";

export const backCardsArr = [
  {
    src: backCard01,
    isMatched: false,
    name: "backCard01",
  },
  {
    src: backCard02,
    isMatched: false,
    name: "backCard02",
  },
  {
    src: backCard03,
    isMatched: false,
    name: "backCard03",
  },
  {
    src: backCard04,
    isMatched: false,
    name: "backCard04",
  },
  {
    src: backCard05,
    isMatched: false,
    name: "backCard05",
  },
  {
    src: backCard06,
    isMatched: false,
    name: "backCard06",
  },
  {
    src: backCard07,
    isMatched: false,
    name: "backCard07",
  },
  {
    src: backCard08,
    isMatched: false,
    name: "backCard08",
  },
  {
    src: backCard09,
    isMatched: false,
    name: "backCard09",
  },
  {
    src: backCard10,
    isMatched: false,
    name: "backCard10",
  },
];
