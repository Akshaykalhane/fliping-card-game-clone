import backCard01 from "./backCard-01.png";
import backCard02 from "./backCard-02.png";
import backCard03 from "./backCard-03.png";
import backCard04 from "./backCard-04.png";
import backCard05 from "./backCard-05.png";
import backCard06 from "./backCard-06.png";
import backCard07 from "./backCard-07.png";
import backCard08 from "./backCard-08.png";
import backCard09 from "./backCard-09.png";
import backCard10 from "./backCard-10.png";

export {
  backCard01,
  backCard02,
  backCard03,
  backCard04,
  backCard05,
  backCard06,
  backCard07,
  backCard08,
  backCard09,
  backCard10,
};
